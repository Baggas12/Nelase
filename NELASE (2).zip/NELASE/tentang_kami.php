
<head>
	<title>Nelase</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
	<div class="wrapper" >
 <nav> 
   <a href="index.php">Beranda</a> 
   <h3>Nelase</h3>
  </nav>
  <main>
   <div class="Fitur">
      <h1 >Anggota C.9</h1>
   </div>
   <section id="boxes">
          <div class="box">
            <img src="img/bagas.jpeg">
            <h3>Bagas Gilang Ananta</h3>
          </div>
           <div class="box">
            <img src="img/nuhe.jpeg">
            <h3>Naufal Herma Irfansyah</h3>
          </div>
          <div class="box">
            <img src="img/baggas.jpeg">
            <h3>Baggas Fariel Agusta</h3>
          </div>
   </section>
</main>
<footer>
  <p>
    Nelase, Copyright @2020.
  </p>
</footer>
</div>